When Task A is finished => Task B

when Task C => Task B

handler

publisher/subscriber

solution

Task A
=> B
Task C
=> B


Handler B